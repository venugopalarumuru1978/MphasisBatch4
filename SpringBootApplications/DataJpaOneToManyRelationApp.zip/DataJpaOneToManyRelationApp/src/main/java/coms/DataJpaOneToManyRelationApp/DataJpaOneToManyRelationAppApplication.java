package coms.DataJpaOneToManyRelationApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataJpaOneToManyRelationAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataJpaOneToManyRelationAppApplication.class, args);
	}

}
