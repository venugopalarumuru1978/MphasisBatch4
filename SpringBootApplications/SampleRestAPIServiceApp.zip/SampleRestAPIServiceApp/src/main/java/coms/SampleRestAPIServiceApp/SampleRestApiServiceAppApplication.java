package coms.SampleRestAPIServiceApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleRestApiServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleRestApiServiceAppApplication.class, args);
	}

}
