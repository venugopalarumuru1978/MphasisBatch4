package coms.SampleRestAPIServiceApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleRestApiServiceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
