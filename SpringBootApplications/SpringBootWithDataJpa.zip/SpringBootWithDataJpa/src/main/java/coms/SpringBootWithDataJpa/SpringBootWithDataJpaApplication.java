package coms.SpringBootWithDataJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithDataJpaApplication.class, args);
	}

}
