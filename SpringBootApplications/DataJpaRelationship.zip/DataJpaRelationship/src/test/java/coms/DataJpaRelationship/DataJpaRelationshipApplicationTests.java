package coms.DataJpaRelationship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataJpaRelationshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
