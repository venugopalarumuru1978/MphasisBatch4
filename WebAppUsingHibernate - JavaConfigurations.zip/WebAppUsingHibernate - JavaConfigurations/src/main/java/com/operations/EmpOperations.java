package com.operations;

import java.io.Serializable;
import java.util.*;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.connections.HiberConfig;
import com.entities.Employee;

public class EmpOperations {

	SessionFactory sf = null;
	
	public EmpOperations()
	{
		sf = HiberConfig.GetConnection();
		System.out.println("Cons");
	}
	
	public int AddEmployee(Employee emp)
	{
		int res = -1;
		try {
			Session session = sf.openSession();
			Transaction trans = session.beginTransaction();
			
			Serializable sz = session.save(emp);
			trans.commit();			
			res = (Integer)sz;
			System.out.println("Emp Inserted with empno " + res);
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			res = -1;
		}
		
		return res;
	}
	
	public List<Employee>  ShowAll()
	{
		Session session = sf.openSession();
		TypedQuery qry = session.createQuery("from Employee");
		List<Employee>  emplist = qry.getResultList();
		return emplist;
	}
	
	public Employee SearchEmp(int eno)
	{
		Employee emp = null;
		Session session = sf.openSession();
		TypedQuery qry = session.createQuery("from Employee where empno=:eno");
		qry.setParameter("eno", eno);
		List<Employee>  emplist = qry.getResultList();
		
		if(!emplist.isEmpty())
			emp = emplist.get(0);
		
		return emp;
	}
	
	public int DeleteEmployee(int eno)
	{
		int result = -1;
		try {
			Session session = sf.openSession();
			Transaction trans = session.beginTransaction();
			TypedQuery qry = session.createQuery("Delete from Employee where empno=:eno");
			qry.setParameter("eno", eno);
			result = qry.executeUpdate();
			trans.commit();
		} catch (Exception e) {
			// TODO: handle exception
			result = -1;
			System.out.println(e);
		}
		return result;
	}
	
	public Employee UserCheck(String email, String pwd)
	{
		//select * from employee where email='naresh@gmail.com' and pswd='123456';
		Employee emp = null;
		try {
			Session session = sf.openSession();
			TypedQuery qry = session.createQuery("from Employee where email=:em and pswd=:pwd");
			qry.setParameter("em", email);
			qry.setParameter("pwd", pwd);
			
			List<Employee>  emplist = qry.getResultList();
			
			if(!emplist.isEmpty())
				emp = emplist.get(0);
			
		} catch (Exception e) {
			// TODO: handle exception
			emp = null;
			System.out.println(e);
		}
		return emp;
	}
	
	public boolean ChangePassword(String npwd, int eno)
	{
		boolean b = false;
		try {
			Session session = sf.openSession();
			Transaction trans = session.beginTransaction();
			TypedQuery qry = session.createQuery("Update Employee set pswd=:pwd where empno=:eno");
			qry.setParameter("eno", eno);
			qry.setParameter("pwd", npwd);
			int res = qry.executeUpdate();
			trans.commit();
			if(res>=1)
				b = true;
		} catch (Exception e) {
			// TODO: handle exception
			b = false;
			System.out.println(e);
		}
		return b;
	}
}
