package coms.EmpServiceProiverApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpServiceProiverAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpServiceProiverAppApplication.class, args);
	}

}
