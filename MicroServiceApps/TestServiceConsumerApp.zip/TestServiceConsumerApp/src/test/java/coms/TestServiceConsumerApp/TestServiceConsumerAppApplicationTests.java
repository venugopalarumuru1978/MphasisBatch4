package coms.TestServiceConsumerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestServiceConsumerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
