package coms.EmpServiceConsumerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpServiceConsumerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
